﻿using BlowFishCS;
using Simias.Encryption;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Security.Cryptography;

namespace WindowsFormsApplication30
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public int temp;
        public string str = string.Empty;
        public string str1;
        public string str2;
        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }
        public string tmp2;
        public string tmp1;
        private void button2_Click(object sender, EventArgs e)
        {
            string tmp;
            byte[] b = new byte[1024];
            byte h;
            UTF8Encoding temp1 = new UTF8Encoding(true);
            BlowFish bf = new BlowFish("04B915BA43FEB5B6");
            tmp = textBox1.Text;
            tmp1 = tmp;
            str1 = bf.Encrypt_CBC(tmp);
            tmp2 = bf.Decrypt_CBC(str1);
            richTextBox2.Text = str1;
            richTextBox3.Text = tmp1;

         temp = 2;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            richTextBox1.Text = textBox1.Text;
        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {
            switch (temp)
            {
                case 1:
                    richTextBox2.Text = str;
                    break;
                case 2:
                    richTextBox2.Text = str1;
                    break;
                default:
                    Console.WriteLine("Default case");
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            str = textBox1.Text;
            str = str.Replace("а", "аа_").
                  Replace("б", "бб_").
                  Replace("в", "вв_").
                  Replace("г", "гг_").
                  Replace("д", "дд_").
                  Replace("е", "ее_").
                  Replace("ё", "ёё_").
                  Replace("ж", "жж_").
                  Replace("з", "зз_").
                  Replace("и", "ии_").
                  Replace("й", "йй_").
                  Replace("к", "кк_").
                  Replace("л", "лл_").
                  Replace("м", "мм_").
                  Replace("н", "нн_").
                  Replace("о", "оо_").
                  Replace("п", "пп_").
                  Replace("р", "рр_").
                  Replace("с", "сс_").
                  Replace("т", "тт_").
                  Replace("у", "уу_").
                  Replace("ф", "фф_").
                  Replace("х", "хх_").
                  Replace("ц", "цц_").
                  Replace("ч", "чч_").
                  Replace("ш", "шш_").
                  Replace("щ", "щщ_").
                  Replace("ъ", "ъъ_").
                  Replace("ы", "ыы_").
                  Replace("ь", "ьь_").
                  Replace("э", "ээ_").
                  Replace("ю", "юю_").
                  Replace("я", "яя_");
            str = str.Replace("аа_", "г").
                Replace("бб_", "д").
                Replace("вв_", "е").
                Replace("гг_", "ё").
                Replace("дд_", "ж").
                Replace("ее_", "з").
                Replace("ёё_", "и").
                Replace("жж_", "й").
                Replace("зз_", "к").
                Replace("ии_", "л").
                Replace("йй_", "м").
                Replace("кк_", "н").
                Replace("лл_", "о").
                Replace("мм_", "п").
                Replace("нн_", "р").
                Replace("оо_", "с").
                Replace("пп_", "т").
                Replace("рр_", "у").
                Replace("сс_", "ф").
                Replace("тт_", "х").
                Replace("уу_", "ц").
                Replace("фф_", "ч").
                Replace("хх_", "ш").
                Replace("цц_", "щ").
                Replace("чч_", "ъ").
                Replace("шш_", "ы").
                Replace("щщ_", "ь").
                Replace("ъъ_", "э").
                Replace("ыы_", "ю").
                Replace("ьь_", "я").
                Replace("ээ_", "а").
                Replace("юю_", "б").
                Replace("яя_", "в");
            richTextBox2.Text = str;
            temp = 1;
        }

        private void richTextBox3_TextChanged(object sender, EventArgs e)
        {
            richTextBox3.Text = tmp1;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void Blowfish_Load(object sender, EventArgs e)
        {
          
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Blowfish — криптографический алгоритм, реализующий блочное симметричное шифрование с переменной длиной ключа   " +
                            "Шифр Цезаря — это вид шифра подстановки, в котором каждый символ в открытом тексте заменяется символом, " +
                            "находящимся на некотором постоянном числе позиций левее или правее него в алфавите. " +
                            "Например, в шифре со сдвигом вправо на 3, А была бы заменена на Г, Б станет Д, и так далее.");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Программа разработана студентом группы 3-Т3О-206Б-16 Дмитрием Фоминым в рамках дисциплины технология программирования в 2018 году");

        }
    }
}
